# CYBERDUDEBIVASH SENTINEL APEX Sigma Rules

Generated: 2026-10-07T11:03:14.885375+00:00
Version: 162.0.0

Use sigma-cli to convert to your target SIEM format:
```
sigma convert -t splunk apex/*.yml
sigma convert -t microsoft365defender apex/*.yml
```
