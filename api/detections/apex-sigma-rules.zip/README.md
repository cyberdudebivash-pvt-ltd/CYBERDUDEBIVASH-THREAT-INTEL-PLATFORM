# CYBERDUDEBIVASH SENTINEL APEX Sigma Rules

Generated: 2026-10-09T16:31:32.697586+00:00
Version: 162.0.0

Use sigma-cli to convert to your target SIEM format:
```
sigma convert -t splunk apex/*.yml
sigma convert -t microsoft365defender apex/*.yml
```
