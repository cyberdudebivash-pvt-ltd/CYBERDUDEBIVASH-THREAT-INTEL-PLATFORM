# CYBERDUDEBIVASH SENTINEL APEX Sigma Rules

Generated: 2026-10-10T23:58:30.563344+00:00
Version: 162.0.0

Use sigma-cli to convert to your target SIEM format:
```
sigma convert -t splunk apex/*.yml
sigma convert -t microsoft365defender apex/*.yml
```
